from distutils.core import setup

setup(name='py_sirius',
      version='0.1',
      py_modules=['sirius', 'bands', '__init__'],
      )
